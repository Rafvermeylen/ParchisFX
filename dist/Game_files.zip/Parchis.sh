#!/bin/bash
java -jar ./ParchisJavaFX-1.0-SNAPSHOT.jar